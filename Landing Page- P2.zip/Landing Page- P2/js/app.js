/*--------------------------------------------------*/
// Part 1, build a dynamic navigation bar
// by creating li with their links in navbar__list:
/*--------------------------------------------------*/


// Create navbar listed item
function create_navbar_li(name) {
    let li = document.createElement('li');
    li.textContent = name;
    return li;
}

// Create <a> element, and link it with section1 in <section>
function createLink1() {
    let link = document.createElement('a');
	link.href = "#section1";
    return link;
}

// Create <a> element, and link it with section2 in <section>
function createLink2() {
    let link = document.createElement('a');
	link.href = "#section2";
    return link;
}

// Create <a> element, and link it with section3 in <section>
function createLink3() {
    let link = document.createElement('a');
	link.href = "#section3";
    return link;
}

// Create <a> element, and link it with section4 in <section>
function createLink4() {
    let link = document.createElement('a');
	link.href = "#section4";
    return link;
}



// get #navbar__list
const nav = document.querySelector('#navbar__list');
// add li  to navbar__list
const s1= nav.appendChild(create_navbar_li('Section 1'));
const s2= nav.appendChild(create_navbar_li('Section 2'));
const s3= nav.appendChild(create_navbar_li('Section 3'));
const s4= nav.appendChild(create_navbar_li('Section 4'));


// add class name for section1
s1.setAttribute('class', 'section_1');
// add <a> to li section_1
s1.appendChild(createLink1());



// add class name for section2
s2.setAttribute('class', 'section_2');
// add <a> to li section_2
s2.appendChild(createLink2());


// add class name for section3
s3.setAttribute('class', 'section_3');
// add <a> to li section_3
s3.appendChild(createLink3());


// add class name for section4
s4.setAttribute('class', 'section_4');
// add <a> to li section_4
s4.appendChild(createLink4());



/*----------------------------------------------------------------------------------*/
// Part 2, here we add (click) Eventlistener on each <a> on navbar__list sections.
// Then, we create smooth scroll function to the navigated <section>.
/*---------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------*/
// Note to the reviewer:
/*

Part 2, was working just fine with me when I created (navbar_list li) on html.
But, when I created them here on JS, they no longer work.
I tried to figured out for days why it is not responding any more.
I am sure that my code is right. But, I couldn't know why.

*/
/*---------------------------------------------------------------------------------*/

const links = document.querySelectorAll('a');

links.forEach(link => link.addEventListener("click", click));
	
function click(event) {
	smooth_scroll(event); 
}


// Smooth_scroll function:
function smooth_scroll(event) {
	event.preventDefault();
	const targetId = event.currentTarget.getAttribute("href");
	
	window.scrollTo({
		top: targetId==="#" ? 0 : document.querySelector(targetId).offsetTop,
		behavior: "smooth"
	})
				
}



/*-------------------------------------------------------------------------------------------------------*/
// Part 3, Create Intersection_Observer to highlight the navegated section in #navbar__list  
// when its <section> in scope.

// I used Intersection_Observer method, to fix the issue mentioned in the rubric, which is this point:
// "It should be clear which section is being viewed while scrolling through the page."
/*------------------------------------------------------------------------------------------------------*/

// function to call all the classes in <section> & navbar__list sections

function select_element_by_class(class_name) {
	return document.querySelector(`.${class_name}`);
}

const sections = [
	select_element_by_class('section1'),
	select_element_by_class('section2'),
	select_element_by_class('section3'),
	select_element_by_class('section4'),
	
];
  
const nav_sections = {
	section1: select_element_by_class('section_1'),
	section2: select_element_by_class('section_2'),
	section3: select_element_by_class('section_3'),
	section4: select_element_by_class('section_4'),
	
};


// intersection observer setting
const observer_settings = {
	root: null,
	rootMargin: '0px',
	threshold: 0.7,
};


// Here in intersection_observer function, 
// First, we call the nav_section that is navigated to its id in <section> which is in the scope right now.
// Second, we add (active) class to that nav_section shown right now.
// Third, we delete (active) class from the others nav_section which is not shown in scope. 

function intersection_observer(inputs, observer) {
	inputs.forEach((input) => {
		if (input.isIntersecting) {
		const nav_section = nav_sections[input.target.id];
		nav_section.classList.add('active');
		Object.values(nav_sections).forEach((section) => {
		  if (section != nav_section) {
			section.classList.remove('active');
		  }
		});

		}
    });
}

const observer = new IntersectionObserver(intersection_observer, observer_settings);
  
sections.forEach((sec) => observer.observe(sec));



//------------------------------------------------------------------------------//


