# Landing Page Project

In this project, we have a web page with many sections.
We have to connect each section in the body with its title in the nav bar.


## This folder contains 3 main files:

1- styles.css 
Which has all css code/ styling code.

2- index.html
Which has the html code for our web page.

3- app.js
Which has the JavaScript code, that responisible for our web page dynamic.


